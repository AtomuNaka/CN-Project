const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const authRoutes = require("./routes/auth");
const messageRoutes = require("./routes/messages");
const app = express();
const socket = require("socket.io");
const http = require("http");
const server = http.createServer(app);
require("dotenv").config();

app.use(cors());
app.use(express.json());

mongoose
  .connect(process.env.MONGO_URL, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("DB Connetion Successfull");
  })
  .catch((err) => {
    console.log(err.message);
  });

app.use("/api/auth", authRoutes);
app.use("/api/messages", messageRoutes);

server.listen(process.env.PORT, () =>
  console.log(`Server started on ${process.env.PORT}`)
);
const io = socket(server, {
  cors: {
    origin: "http://localhost:3000",
    credentials: true,
  },
});

global.onlineUsers = new Map();
// const onlineUsers = new Map();
io.on("connection", (socket) => {
  console.log(`User connected: ${socket.id}`);
  // global.chatSocket = socket;
  socket.on("add-user", (userId) => {
    onlineUsers.set(userId, socket.id);
  });

  socket.on("send-msg", (data) => {
    const sendUserSocket = onlineUsers.get(data.to);
    if (sendUserSocket) {
      // socket.to(sendUserSocket).emit("msg-recieve", data.msg);
      io.to(sendUserSocket).emit("msg-recieve", data.msg);
    }
  });
  const users = {};
  if (!users[socket.id]) {
    users[socket.id] = socket.id;
  }
  socket.emit("yourID", socket.id);
  io.sockets.emit("allUsers", users);

  socket.on("disconnect", () => {
    console.log(`User disconnected: ${socket.id}`);
    delete users[socket.id];
  });

  socket.on("callUser", (data) => {
    io.to(data.userToCall).emit("hey", {
      signal: data.signalData,
      from: data.from,
    });

    socket.on("acceptCall", (data) => {
      io.to(data.to).emit("callAccepted", data.signal);
    });
  });

  //   io.on("connection", (socket) => {
  //     // if (!users[socket.id]) {
  //     //   users[socket.id] = socket.id;
  //     // }
  //     // socket.emit("yourID", socket.id);
  //     // io.sockets.emit("allUsers", users);
  //     // socket.on("disconnect", () => {
  //     //   delete users[socket.id];
  //     // });
  //     // socket.on("callUser", (data) => {
  //     //   io.to(data.userToCall).emit("hey", {
  //     //     signal: data.signalData,
  //     //     from: data.from,
  //     //   });
  //   });

  //   // socket.on("acceptCall", (data) => {
  //   //   io.to(data.to).emit("callAccepted", data.signal);
  //   // });
});
